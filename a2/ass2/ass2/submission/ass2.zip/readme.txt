READ ME

A makefile has been included to compile and build the program.

Run the make command in the unizipped directory src.

$ make

The compilation uses g++, and was tested on the lab machines (ubuntu), and Banshee.

Run the program like so:

./sim

The program will read the file name from standard input.