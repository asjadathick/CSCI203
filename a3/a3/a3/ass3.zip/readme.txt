Read Me

The Matrix is generated using the script provided, with the size (N) passed in through stdin. (generateAdjM)

The code can be compiled by running 

$ ./a3compile


The code can then be executed by running

$ ./a3run

The size of the matrix can be altered by editing the script file a3run by replacing N with the size required.

./generateAdjM N

The script requires g++ compiler to compile code. Tested on the Ubuntu environment.