## CSCI203 A4
Run a4compile to compile
Run a4run to run
